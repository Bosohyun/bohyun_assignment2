﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FinalTest.Models
{
    public class HybridPiano : Piano
    {
        public override bool IsRealAction { get => true; }
 
    }
}
