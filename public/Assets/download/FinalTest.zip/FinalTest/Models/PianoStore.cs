﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FinalTest.Models
{
    public class PianoStore
    {
        public string PianoStoreGuid { get; set;}
        public string StoreName { get; set; }
        public List<AccousticPiano> AccousticPianos { get; set; }
        public List<HybridPiano> HybridPianos { get; set; }
        public List<DigitalPiano> DigitalPianos { get; set; }

        public int ValueOfOwnedPianos
        {
            get
            {
                int total = 0;

                foreach (var accousticPiano in this.AccousticPianos)
                {
                    total += accousticPiano.Value;
                }
                foreach (var digitalPiano in this.DigitalPianos)
                {
                    total += digitalPiano.Value;
                }
                foreach (var hybridPiano in this.HybridPianos)
                {
                    total += hybridPiano.Value;
                }

                return total;
            }
        }
        public PianoStore()
        {
            this.PianoStoreGuid = Guid.NewGuid().ToString();
            this.AccousticPianos = new List<AccousticPiano>();
            this.HybridPianos = new List<HybridPiano>();
            this.DigitalPianos = new List<DigitalPiano>();


        }

    }
}
