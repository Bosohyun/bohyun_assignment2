﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FinalTest.Models
{
    public abstract class Piano
    {
        protected int value;
        public string PianoGuid { get; set; }
        public string BrandName { get; set; }
        public string ModelName { get; set; }
        public bool IsSeconhand { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public abstract bool IsRealAction { get; }
        public int Value
        {
            get
            {
                return this.value;
            }
            set
            {
                if (value >= 0)
                    this.value = value;
                else
                    throw new Exception("The value of piano cannot be null!");
            }
        }

        public Piano()
        {
            this.PianoGuid = Guid.NewGuid().ToString();
        }
    }
}
