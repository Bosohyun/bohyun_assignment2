﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FinalTest.Models
{
    public class DigitalPiano : Piano
    {
        public override bool IsRealAction { get => false; }

    }
}
