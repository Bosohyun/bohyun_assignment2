﻿using System;
using System.Collections.Generic;
using System.Text;
using FinalTest.Services;
using FinalTest.Models;
using FinalTest.Services.Interfaces;
using System.IO;
using System.Xml.Serialization;

namespace FinalTest.Services
{
    public class StockService : IService<PianoStore>
    {
        private string directory = @"xmldata\";
        public List<PianoStore> Load()
        {
            List<PianoStore> pianoStores = null;
            var files = Directory.GetFiles(this.directory);

            if (files != null && files.Length > 0)
            {
                pianoStores = new List<PianoStore>();

                foreach (string file in files)
                {
                    PianoStore pianoStore = null;

                    var serializer = new XmlSerializer(typeof(PianoStore));
                    
                    using (var stream = new FileStream(file, FileMode.Open, FileAccess.Read))
                    {
                        pianoStore = (PianoStore)serializer.Deserialize(stream);
                    }
                    pianoStores.Add(pianoStore);
                }
            }
            return pianoStores;

        }
        public void Save(PianoStore obj)
        {
            var serializer = new XmlSerializer(typeof(PianoStore));

            using (var stream = new FileStream(this.directory + obj.PianoStoreGuid + ".xml",FileMode.Create, FileAccess.Write))
            {
                serializer.Serialize(stream, obj);
            }
        }
        public void Update(PianoStore obj)
        {
            string filename = this.directory + obj.PianoStoreGuid + ".xml";
            if (File.Exists(filename))
                File.Delete(filename);

            this.Save(obj);
        }
        public void Delete(PianoStore obj)
        {
            string filename = this.directory + obj.PianoStoreGuid + ".xml";
            if (File.Exists(filename))
                File.Delete(filename);
        }
    }
}
