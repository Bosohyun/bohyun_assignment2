﻿using FinalTest.Models;
using FinalTest.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
namespace FinalTest
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            btnCreateStore.Click += this.OnCreateStores;
            btnDeleteStore.Click += this.OnDeleteStores;
            btnCreateStock.Click += this.OnCreateStock;
            btnDeleteStock.Click += this.OnDeleteStock;
            dataStores.SelectionChanged += this.OnSelectStore;
            dataStores.ItemsSource = this.LoadStores();

        }

        public List<PianoStore> LoadStores()
        {
            var stockService = new StockService();
            var pianoStores = stockService.Load();

            return pianoStores;
        }

        private void OnCreateStores(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtStoreName.Text))
            {
                MessageBox.Show("To create a store, you must input the name of store");
                return;
            }

            var pianoStore = new PianoStore()
            {
                StoreName = txtStoreName.Text
            };

            //Save Store
            var stockService = new StockService();
            stockService.Save(pianoStore);

            dataStores.ItemsSource = LoadStores();

            txtStoreName.Text = null;

            MessageBox.Show("Account successfully created!");

        }

        private void OnDeleteStores(object sender, EventArgs e)
        {
            //Error control ( Unable to cast object of type 'MS.Internal.NamedObject' error)
            //Without this control, if I click delete button, while I click empty space in store data grid,
            //the program is crashed
            var selectedStoreError = dataStores.SelectedItem;
            if (selectedStoreError == null)
                return;
            if (selectedStoreError.GetType() != typeof(PianoStore))
                return;
            var selectedStore = (PianoStore)selectedStoreError;

            if (selectedStore == null)
            {
                MessageBox.Show("Please select an store to continue.");
                return;
            }
            //Delete Store
            var stockService = new StockService();
            stockService.Delete(selectedStore);

            dataStores.ItemsSource = LoadStores();
            MessageBox.Show("Account successfully deleted!");

        }
        private void OnSelectStore(object sender, EventArgs e)
        {
            //Error control ( Unable to cast object of type 'MS.Internal.NamedObject' error) 
            //Without this control, if I click empty space in store data grid, the program is crashed
            var selectedStoreError = dataStores.SelectedItem;
            if (selectedStoreError == null)
                return;
            if (selectedStoreError.GetType() != typeof(PianoStore))
                return;
            
            var selectedStore = (PianoStore)selectedStoreError;
            
            if (selectedStore == null)
            {
              
                return;
            }

            lblSelectedStore.Content = $"Pianos for Store: {selectedStore.StoreName}";

            List<Piano> pianos = new List<Piano>();

            
            foreach (var accoustic in selectedStore.AccousticPianos)
            {
                pianos.Add(accoustic);
            }

            foreach (var hybrid in selectedStore.HybridPianos)
            {
                pianos.Add(hybrid);
            }

            foreach (var digital in selectedStore.DigitalPianos)
            {
                pianos.Add(digital);
            }

        

            pianos = pianos.OrderByDescending(t => t.DateOfBirth).ToList();
            dataStocks.ItemsSource = pianos;
        }

        private void OnCreateStock(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtBrand.Text))
            {
                MessageBox.Show("Please input Brand name");

                return;
            }

            if (string.IsNullOrWhiteSpace(txtModelName.Text))
            {
                MessageBox.Show("Please input Model name");

                return;
            }

            if (checkIsSecondHand.IsChecked == null)
            {
                MessageBox.Show("Please choose whether the piano is second-hand or not");

                return;
            }

            if (!int.TryParse(txtPrice.Text, out _))
            {
                MessageBox.Show("Please input integer value in Value");
                return;
            }

            var selectedStore = (PianoStore)dataStores.SelectedItem;

            if (selectedStore == null)
            {
                MessageBox.Show("Please select an store to continue.");
                return;
            }


            
            if (checkIsSecondHand.IsChecked == true)
            {
                if(btnAccoustic.IsChecked == true)
                {
                    var piano = new AccousticPiano()
                    {
                        BrandName = txtBrand.Text,
                        ModelName = txtModelName.Text,
                        Value = int.Parse(txtPrice.Text),
                        DateOfBirth = dateDateOfBirth.SelectedDate,
                        IsSeconhand = true
                    };

                    selectedStore.AccousticPianos.Add(piano);
                }

                else if (btnDigital.IsChecked == true)
                {
                    var piano = new DigitalPiano()
                    {
                        BrandName = txtBrand.Text,
                        ModelName = txtModelName.Text,
                        Value = int.Parse(txtPrice.Text),
                        DateOfBirth = dateDateOfBirth.SelectedDate,
                        IsSeconhand = true
                    };
                    selectedStore.DigitalPianos.Add(piano);

                }

                else if (btnHybrid.IsChecked == true)
                {
                    var piano = new HybridPiano()
                    {
                        BrandName = txtBrand.Text,
                        ModelName = txtModelName.Text,
                        Value = int.Parse(txtPrice.Text),
                        DateOfBirth = dateDateOfBirth.SelectedDate,
                        IsSeconhand = true
                    };
                    selectedStore.HybridPianos.Add(piano);

                }

                else
                {
                    MessageBox.Show("Please choose type of the piano");
                    return;
                }

              
            }
            else
            {  
                if (btnAccoustic.IsChecked == true)
                {
                    var piano = new AccousticPiano()
                    {
                        BrandName = txtBrand.Text,
                        ModelName = txtModelName.Text,
                        Value = int.Parse(txtPrice.Text),
                        DateOfBirth = dateDateOfBirth.SelectedDate,
                        IsSeconhand = false
                    };
                    selectedStore.AccousticPianos.Add(piano);
                }

                else if (btnDigital.IsChecked == true)
                {
                    var piano = new DigitalPiano()
                    {
                        BrandName = txtBrand.Text,
                        ModelName = txtModelName.Text,
                        Value = int.Parse(txtPrice.Text),
                        DateOfBirth = dateDateOfBirth.SelectedDate,
                        IsSeconhand = false
                    };
                    selectedStore.DigitalPianos.Add(piano);

                }

                else if (btnHybrid.IsChecked == true)
                {
                    var piano = new HybridPiano()
                    {
                        BrandName = txtBrand.Text,
                        ModelName = txtModelName.Text,
                        Value = int.Parse(txtPrice.Text),
                        DateOfBirth = dateDateOfBirth.SelectedDate,
                        IsSeconhand = false
                    };
                    selectedStore.HybridPianos.Add(piano);
                }

                else
                {
                    MessageBox.Show("Please choose type of the piano");
                    return;
                }
            }

            var stockService = new StockService();
            stockService.Update(selectedStore);
            dataStores.ItemsSource = LoadStores();

            List<Piano> pianos = new List<Piano>();

            foreach (var accoustic in selectedStore.AccousticPianos)
            {
                pianos.Add(accoustic);
            }

            foreach (var digital in selectedStore.DigitalPianos)
            {
                pianos.Add(digital);
            }

            foreach (var hybrid in selectedStore.HybridPianos)
            {
                pianos.Add(hybrid);
            }

            dataStocks.ItemsSource = null;
            dataStocks.ItemsSource = pianos;

            txtBrand.Text = null;
            txtModelName.Text = null;
            checkIsSecondHand.IsChecked = false;


            MessageBox.Show($"a piano added to Stock {selectedStore.StoreName}");

        }

        private void OnDeleteStock(object sender, EventArgs e)
        {
            var selectedStore = (PianoStore)dataStores.SelectedItem;
            var temp = selectedStore;


            //Error control ( Unable to cast object of type 'MS.Internal.NamedObject' error)
            //Without this control, if I click delete button, while I click empty space in stock data grid,
            //the program is crashed
            if (selectedStore == null)
            {
                return;
            }

            if (dataStocks.SelectedItem.GetType() == typeof(HybridPiano)) {
                var selectedStock = (HybridPiano)dataStocks.SelectedItem;
                selectedStore.HybridPianos.Remove(selectedStock);
            }

            else if (dataStocks.SelectedItem.GetType() == typeof(DigitalPiano))
            {
                var selectedStock = (DigitalPiano)dataStocks.SelectedItem;
                selectedStore.DigitalPianos.Remove(selectedStock);
            }

            else if (dataStocks.SelectedItem.GetType() == typeof(AccousticPiano))
            {
                var selectedStock = (AccousticPiano)dataStocks.SelectedItem;
                selectedStore.AccousticPianos.Remove(selectedStock);
            }

            else
            {
                return;
            }

            var stockService = new StockService();
            stockService.Update(selectedStore);
            stockService.Load();
            selectedStore = temp;



            List<Piano> pianos = new List<Piano>();

            foreach (var accoustic in selectedStore.AccousticPianos)
            {
                pianos.Add(accoustic);
            }

            foreach (var digital in selectedStore.DigitalPianos)
            {
                pianos.Add(digital);
            }

            foreach (var hybrid in selectedStore.HybridPianos)
            {
                pianos.Add(hybrid);
            }

            dataStocks.ItemsSource = null;
            dataStocks.ItemsSource = pianos;
        

            MessageBox.Show($"Deleted!");
        }
    }
}


